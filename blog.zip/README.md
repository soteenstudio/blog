# SoTeen Studio Blog

Blog satu halaman (daftar artikel) SoTeen Studio, terpisah dari web utama (Next.js) tetapi memakai token desain,
font, dan komponen visual yang sama. Dibangun dengan **Astro** (SSR) dan **Turso** (libSQL)
untuk artikel, komentar, suka, dan akun login.

## Menjalankan secara lokal

```bash
pnpm install            # atau npm install
cp .env.example .env    # bawaannya memakai file SQLite lokal (local.db)
pnpm db:migrate         # membuat tabel
pnpm dev                # http://localhost:4321
```

Butuh Node.js 20.6 atau lebih baru.

## Memakai Turso

```bash
turso db create soteen-blog
turso db show soteen-blog --url          # -> TURSO_DATABASE_URL
turso db tokens create soteen-blog       # -> TURSO_AUTH_TOKEN
```

Isi nilai itu di `.env` (atau environment variable di hosting), lalu jalankan `pnpm db:migrate`.

## Halaman khusus untuk menulis dan mengatur izin

Tidak ada artikel bawaan (hardcoded): setiap artikel dibuat manual lewat halaman khusus.

| Halaman | Siapa yang boleh | Fungsi |
| --- | --- | --- |
| `/dashboard/posts/new` | admin dan akun berizin | menulis artikel baru (Markdown) |
| `/dashboard` | admin dan akun berizin | daftar artikel; penulis hanya melihat miliknya, admin melihat semua |
| `/dashboard/posts/<id>` | pemilik artikel dan admin | mengubah, menerbitkan, menghapus |
| `/dashboard/users` | admin dan pengelola (Founder, dll.) | atur job; admin juga izin menulis, blokir, hapus akun |
| `/profile` | semua akun | foto, profesi, dan daftar pengikut |
| `/u/<id>` | publik | profil publik dan tombol Ikuti |

**Menentukan admin.** Isi `ADMIN_EMAILS` di `.env` (email dipisah koma). Akun yang emailnya ada di daftar
otomatis menjadi admin begitu mendaftar atau masuk:

```
ADMIN_EMAILS=kamu@contoh.com,rekan@contoh.com
```

Karena belum ada verifikasi email, daftarkan akun admin segera setelah deploy dan jangan
mempublikasikan email admin. Alternatifnya, `pnpm db:make-admin email@anda.com` menjadikan akun yang
sudah ada sebagai admin permanen di database.

Mencabut izin berlaku seketika; artikel lama penulis itu tetap tersimpan dan tetap dikelola admin.
Bila database dibuat sebelum fitur izin ada, jalankan `pnpm db:migrate` lagi (kolom `users.can_post`
ditambahkan otomatis tanpa menghapus data).

## Job akun, blokir, dan hapus akun

- **Job** (kolom "Job di studio" di profil) tidak lagi bisa diubah sendiri. Yang boleh mengaturnya: **admin**
  dan pemegang job pengelola yang terdaftar di `jobManagerProfessions` (`src/data/site.ts`, bawaan: Founder,
  Co-Founder, Owner, CEO, CTO, COO). Daftar itu dicocokkan tanpa peduli huruf besar/kecil atau tanda hubung.
- Pemegang job pengelola hanya bisa mengatur job akun biasa. Memberi atau mengubah job dari daftar itu, serta
  mengubah job admin dan sesama pengelola, tetap hak admin, supaya hak ini tidak bisa diwariskan sendiri.
- Halaman `/dashboard/users` ("Kelola akun") terbuka untuk admin dan pengelola. **Memberi izin menulis,
  memblokir, dan menghapus akun hanya untuk admin.** Admin tidak bisa memblokir/menghapus admin lain atau dirinya.
- **Blokir**: akun langsung keluar dari semua sesi dan tidak bisa masuk (pesan khusus muncul bila kata sandinya
  benar). Bisa dibuka lagi kapan saja. Di instance server lain, sesi yang sudah ter-cache bisa bertahan sampai
  `cacheConfig.sessionSeconds` (30 detik).
- **Hapus akun** permanen: komentar, suka, dan relasi ikutnya ikut terhapus. Artikelnya **tetap ada** dengan
  nama penulis tanpa tautan profil.
- Jalankan `pnpm db:migrate` sekali setelah memperbarui kode (menambah kolom `users.banned_at`).

## Kategori artikel

Daftar kategori ada di satu file: **`src/data/categories.mjs`**. Form menulis memakai daftar pilihan (bukan
ketik bebas), dan labelnya mengikuti bahasa antarmuka, mis. `general` tampil "General" di EN dan "Umum" di ID.

- **Tambah**: tambah satu objek `{ id, labels: { id, en } }`. Langsung muncul, tanpa migrasi.
- **Ganti nama tampilan**: ubah `labels` saja. Jangan ubah `id` (itu yang tersimpan di database).
- **Hapus**: buang objeknya. Artikel lama tetap tampil (dengan id sebagai label) sampai penulisnya memilih
  kategori baru; atau pindahkan sekaligus dengan `pnpm db:move-category <id-lama> <id-baru>`.
- Kategori teks bebas dari versi lama ("Umum", "Open Source") otomatis diubah ke id oleh `pnpm db:migrate`.

## Keamanan login dan pendaftaran

| Proteksi | Di mana | Catatan |
| --- | --- | --- |
| Validasi email ketat | daftar (server + live di browser) | menolak bentuk salah, TLD cadangan (`.test`, `.local`), domain isi asal (`ngasal.com` dan subdomainnya, nama yang memuat "ngasal"), email sekali pakai, dan salah ketik populer (`gmial.com`). Daftar ada di `src/lib/email-rules.ts`; tambah lewat env `BLOCKED_EMAIL_DOMAINS` |
| Cek domain (MX/DNS) | daftar (server) | domain yang tidak ada atau menyatakan tidak menerima email ditolak; bila DNS timeout, dianggap lolos |
| Pengukur kekuatan sandi | daftar | bar + label + saran, ID/EN (tanpa angka "waktu bobol", karena angkanya tidak bisa akurat). Server menolak sandi di bawah skor "Cukup" (`src/lib/password-strength.ts`) |
| Cloudflare Turnstile | login dan daftar | token diverifikasi di server (`src/lib/turnstile.ts`) |
| Kolom jebakan (honeypot) | login dan daftar | bot yang mengisi semua kolom ditolak |
| Batas laju | login: 10/15 menit per IP dan 8/15 menit per email; daftar: 5/jam per IP | diatur di `limits` pada `src/data/site.ts`. Dihitung per instance server |
| Header keamanan | semua halaman | `X-Frame-Options`, `nosniff`, `Referrer-Policy`, HSTS di produksi; halaman login/daftar `no-store` |

**Mengaktifkan Turnstile.** Buat widget di dash.cloudflare.com > Turnstile (tambahkan domain blog Anda),
lalu isi `TURNSTILE_SITE_KEY` dan `TURNSTILE_SECRET_KEY` di environment variable Vercel. Di `.env` lokal
sudah terisi kunci uji Cloudflare yang selalu lolos. Bila kedua kunci kosong, verifikasi dilewati dan
server menulis peringatan di log, jadi pastikan keduanya terisi di produksi.

## Fitur pembaca dan penulis

- **Terjemahan artikel:** di form menulis, pilih bahasa utama lalu isi bagian *Terjemahan (opsional)*.
  Pembaca otomatis melihat versi sesuai bahasa yang dipilih; bila terjemahan belum ada, teks utama
  tampil dengan catatan. Kategori adalah satu nilai untuk semua bahasa.
- **Pratinjau Markdown:** tab *Tulis/Pratinjau* di setiap kolom isi. HTML dirender dan disanitasi di
  server (`/api/preview`, hanya untuk akun berizin menulis).
- **Profil:** `/profile` untuk mengubah foto (dipangkas jadi persegi 256 px di browser lalu disimpan di
  database Turso, tampil lewat `/avatar/<id>`), profesi di studio, dan melihat daftar pengikut.
  Profil publik di `/u/<id>` memiliki tombol Ikuti.
- **Progres membaca** di tepi atas halaman artikel, dan tombol **Bagikan** (WhatsApp, X, Facebook,
  LinkedIn, Telegram, email, salin tautan, serta menu bagikan bawaan perangkat bila tersedia).

Jalankan `pnpm db:migrate` setelah memperbarui: kolom baru (profil, terjemahan) dan tabel `follows`
ditambahkan tanpa menghapus data.

## Bahasa

Bahasa ditentukan oleh awalan URL: `/id/...` dan `/en/...` (mis. `/en/posts/judul`). Alamat tanpa awalan
otomatis diarahkan ke bahasa terakhir yang dibuka (cookie `lang`), bawaannya Indonesia. Tombol bahasa di
navbar (ID/EN) hanyalah tautan ke versi bahasa lain dari halaman yang sama. Teks antarmuka ada di
`src/data/copy/id.ts` dan `src/data/copy/en.ts` (kunci harus sama; TypeScript akan memberi tahu bila
ada yang kurang). Isi artikel tidak diterjemahkan otomatis; penulis mengisi terjemahannya sendiri (lihat di atas).

## Cache dan pembatasan laju

Supaya kuota Turso (rows read/written) awet:

- **Cache data di memori** (`src/lib/cache.ts`, lama simpan di `cacheConfig` dalam `src/data/site.ts`):
  daftar artikel dan kategori, artikel per slug, komentar, profil, foto profil, dan sesi login. Cache
  dibuang seketika di instance yang menangani penulisan (buat/ubah/hapus artikel, suka, komentar, ikuti,
  ubah profil). Instance lain mengikuti TTL, jadi perubahan bisa terlambat sampai satu menit.
  Bila Turso error atau kuotanya habis, data lama tetap dipakai (hingga `staleIfErrorSeconds`).
- **Kueri hemat:** jumlah artikel per halaman dihitung dari daftar kategori yang sudah di-cache, dan
  kategori/halaman yang tidak ada dijawab tanpa menyentuh database.
- **Foto profil:** di-cache browser dan CDN (`s-maxage`), dan permintaannya tidak lagi mencari sesi.
- **Batas laju** (`limits` di `src/data/site.ts`): per IP untuk halaman, penulisan, dan foto profil; per
  akun untuk suka, komentar (per menit dan per jam), hapus komentar, ikuti, foto profil, dan pratinjau.
  Melewati batas menghasilkan HTTP 429 dengan header `Retry-After`. Penghitungnya di memori tiap instance,
  jadi batasnya berlaku per instance serverless, bukan total.

## Struktur

```
src/
  data/site.ts        identitas studio, navigasi, tautan sosial & legal
  data/copy/          teks antarmuka per bahasa (id.ts, en.ts, index.ts)
  styles/global.css   token warna & animasi (sama dengan web utama) + gaya isi artikel
  layouts/            BaseLayout (tema gelap/terang, animasi scroll)
  components/         Navbar, Footer, PostCard, Comments, LikeButton, PostForm, ...
  lib/                db, cache, auth, posts, comments, likes, markdown, validasi, rate limit
  pages/              /, /posts/[slug], /login, /register, /dashboard/*, /api/*
scripts/              migrate, make-admin
```

## Menyamakan dengan web utama

- Warna, radius, dan font ada di `src/styles/global.css` dan `tailwind.config.mjs`. Bila `--brand`
  di web utama berubah, ubah juga di sini.
  seperti di web utama.
- Pilihan tema tersimpan di `localStorage`, jadi tidak otomatis terbawa antar domain/subdomain.

## Keamanan yang sudah ditangani

- Kata sandi di-hash dengan scrypt (salt per pengguna); sesi berupa token acak, hanya hash-nya yang disimpan.
- Cookie sesi `HttpOnly`, `SameSite=Lax`, dan `Secure` di produksi; Astro memeriksa origin untuk form POST.
- Komentar selalu ditampilkan sebagai teks (tidak pernah HTML); isi artikel disanitasi setelah Markdown dirender.
- Pembatas laju untuk login, pendaftaran, komentar, dan suka. Ini disimpan di memori proses,
  jadi bila nanti berjalan di banyak instance/serverless, pindahkan ke penyimpanan bersama.
- Parameter `?next=` hanya menerima path internal.

## Deploy

Memakai adapter `@astrojs/node` (`pnpm build && pnpm start`), cocok untuk VPS atau Docker. Untuk Vercel,
Netlify, atau Cloudflare, ganti adapter di `astro.config.mjs` dengan adapter platform tersebut.
Atur variabel `TURSO_DATABASE_URL`, `TURSO_AUTH_TOKEN`, `ADMIN_EMAILS`, dan `SITE_URL`.
Bila berada di belakang reverse proxy, pastikan IP klien diteruskan agar pembatas laju akurat.
